package com.cognizant.dailymutualfund;


import org.junit.jupiter.api.Test;



class DailyMutualFundNAVAApplicationTests {

	@Test
	void contextLoads() {
		
	}

}
